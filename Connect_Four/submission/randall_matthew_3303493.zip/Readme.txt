COMP2230_Algorithms
Assignment 1
Author: Matthew Randall

Right now my engine is set to run at depth 7 which creates a tie which is not handled with the given Coordinator. If this is all good just leave as is. 

To Compile:
javac *.java

Thanks Nathan your a freakin legend absolutely loved this course btw.

Sincerely,
A cocky student